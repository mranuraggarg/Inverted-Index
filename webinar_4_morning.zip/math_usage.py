from module_math import square

print(__name__)

# x = int(input())
# print(square(x))
