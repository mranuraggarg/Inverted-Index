class Event:
    def __init__(self, description, event_date):
        self.description = description
        self.event_date = event_date

    @classmethod
    def parse_event(cls, user_input):
        event, date = user_input.split(maxsplit=1)
        date = tuple(map(int, date.split()))
        return cls(event, date)


event = Event('Party', (2025, 12, 31))
print(event.description, event.event_date)

income_message = 'Birthday 2023 6 9'
# description, event_date = Event.parse_event('sdf', income_message)
# event_2 = Event(description, event_date)

event_2 = Event.parse_event(income_message)
print(event_2.description, event_2.event_date)
