# import sys
#
#
# # print(sys.argv)
# x = int(sys.argv[1])
# y = int(sys.argv[2])
#
# print(x + y)


def my_print(*args):
    print(*args)


my_print(1, 3, 5)



