def square(x):
    return x**2


def factorial(x):
    pass


if __name__ == '__main__':
    print('Start testing')
    print(25 == square(5))
    print(16 == square(4))
    print('End testing')
