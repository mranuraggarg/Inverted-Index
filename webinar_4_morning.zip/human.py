class Human:
    def __init__(self, name, age):
        if self.is_age_valid(age):
            self.name = name
            self.age = age
        else:
            raise ValueError("age isn't valid")

    @staticmethod
    def is_age_valid(age):
        return 0 < age < 150


human = Human('Tom', 30)
print(Human.is_age_valid(67))
print(Human.is_age_valid(-67))
